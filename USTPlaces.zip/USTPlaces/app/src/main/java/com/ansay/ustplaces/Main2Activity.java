package com.ansay.ustplaces;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void displayMsg1 (View view){
        Intent intent = new Intent (Intent.ACTION_VIEW);
        intent.setData(Uri.parse("https://foursquare.com/v/roque-rua%C3%B1o-building/4d4ede8a9d662d43d6a94b00"));
        startActivity(intent);
    }

    public void displayMsg2 (View view){
        Intent intent = new Intent (Intent.ACTION_VIEW);
        intent.setData(Uri.parse("https://en.wikipedia.org/wiki/Buenaventura_Garcia_Paredes,_O.P._Building"));
        startActivity(intent);
    }

    public void displayMsg3 (View view){
        Intent intent = new Intent (Intent.ACTION_VIEW);
        intent.setData(Uri.parse("https://en.wikipedia.org/wiki/University_of_Santo_Tomas_Main_Building"));
        startActivity(intent);
    }

    public void displayMsg4 (View view){
        Intent intent = new Intent (Intent.ACTION_VIEW);
        intent.setData(Uri.parse("https://en.wikipedia.org/wiki/Quadricentennial_Pavilion"));
        startActivity(intent);
    }
}
